﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using InsumosMedicosJDJ.Data;
using InsumosMedicosJDJ.Models;

namespace InsumosMedicosJDJ.Controllers
{
    public class ProduccionesController : Controller
    {
        private readonly InsumosContext _context;

        public ProduccionesController(InsumosContext context)
        {
            _context = context;
        }

        // GET: Producciones
        public async Task<IActionResult> Index()
        {
            return View(await _context.Producciones.ToListAsync());
        }

        // GET: Producciones/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var producciones = await _context.Producciones
                .FirstOrDefaultAsync(m => m.ID == id);
            if (producciones == null)
            {
                return NotFound();
            }

            return View(producciones);
        }

        // GET: Producciones/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Producciones/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Fecha_produccion,Cantidad_prendas,Costo_unidad")] Producciones producciones)
        {
            if (ModelState.IsValid)
            {
                _context.Add(producciones);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(producciones);
        }

        // GET: Producciones/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var producciones = await _context.Producciones.FindAsync(id);
            if (producciones == null)
            {
                return NotFound();
            }
            return View(producciones);
        }

        // POST: Producciones/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Fecha_produccion,Cantidad_prendas,Costo_unidad")] Producciones producciones)
        {
            if (id != producciones.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(producciones);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProduccionesExists(producciones.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(producciones);
        }

        // GET: Producciones/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var producciones = await _context.Producciones
                .FirstOrDefaultAsync(m => m.ID == id);
            if (producciones == null)
            {
                return NotFound();
            }

            return View(producciones);
        }

        // POST: Producciones/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var producciones = await _context.Producciones.FindAsync(id);
            _context.Producciones.Remove(producciones);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ProduccionesExists(int id)
        {
            return _context.Producciones.Any(e => e.ID == id);
        }
    }
}

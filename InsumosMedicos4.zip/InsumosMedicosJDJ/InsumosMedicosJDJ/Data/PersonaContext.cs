﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using InsumosMedicosJDJ.Models;

namespace InsumosMedicosJDJ.Data
{
    public class PersonaContext : DbContext
    {
        public PersonaContext (DbContextOptions<PersonaContext> options)
            : base(options)
        {
        }

        public DbSet<InsumosMedicosJDJ.Models.Persona> Persona { get; set; }
    }
}

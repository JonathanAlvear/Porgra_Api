﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace InsumosMedicosJDJ.Migrations.Persona
{
    public partial class inicioPersona : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ProductoTela",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    NombreProducto = table.Column<string>(nullable: true),
                    Modelo = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductoTela", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Persona",
                columns: table => new
                {
                    Id = table.Column<Guid>(nullable: false),
                    Cedula = table.Column<string>(nullable: true),
                    Nombres = table.Column<string>(nullable: true),
                    Apellidos = table.Column<string>(nullable: true),
                    Telefono = table.Column<string>(nullable: true),
                    ProductoTelaId = table.Column<Guid>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Persona", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Persona_ProductoTela_ProductoTelaId",
                        column: x => x.ProductoTelaId,
                        principalTable: "ProductoTela",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Persona_ProductoTelaId",
                table: "Persona",
                column: "ProductoTelaId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Persona");

            migrationBuilder.DropTable(
                name: "ProductoTela");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsumosMedicosJDJ.Models
{
    public class Producciones
    {
        public int ID { get; set; }

        public int Fecha_produccion { get; set; }

        public int Cantidad_prendas { get; set; }

        public int Costo_unidad { get; set; }

    }
}

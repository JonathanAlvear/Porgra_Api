﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace InsumosMedicosJDJ.Models
{
    public class Persona
    {
        //relaciones de personas con productos telas
        public Guid Id { get; set; }

        public string Cedula { get; set; }

        public string Nombres { get; set; }

        public string Apellidos { get; set; }

        public string Telefono { get; set; }

        public List<PersonaProductoTela> PersonaProductoTelas { get; set; }

    }
}

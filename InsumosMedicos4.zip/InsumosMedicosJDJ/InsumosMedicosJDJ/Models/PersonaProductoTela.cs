﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace InsumosMedicosJDJ.Models
{
    public class PersonaProductoTela
    {
        [Key]
        [ForeignKey(name: "Persona")]

        public int PersonaId { get; set; }

        public Persona Persona { get; set; }
        [Key]
        [ForeignKey(name: "ProductoTela")]

        public int ProductoTelaID { get; set; }

        public ProductoTela ProductoTela { get; set; }


    }
}

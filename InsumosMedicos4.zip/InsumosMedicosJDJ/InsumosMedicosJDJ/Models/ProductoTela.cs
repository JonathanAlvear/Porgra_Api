﻿using System;
using System.Collections.Generic;

namespace InsumosMedicosJDJ.Models
{
    public class ProductoTela
    {

        //relaciones de productos telas con personas
        public Guid Id { get; set; }

        public string NombreProducto { get; set; }

        public string Modelo { get; set; }

        public List<PersonaProductoTela> PersonaProductoTelas { get; set; }
    }
}